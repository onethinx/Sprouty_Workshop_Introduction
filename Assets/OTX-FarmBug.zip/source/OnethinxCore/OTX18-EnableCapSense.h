#include "project.h"
#include "OnethinxCore01.h"
#include "OnethinxExt01.h"

static coreConfiguration_t	coreConfigCapSenseTest = {
	.Join =
	{
		.KeysPtr = 			0,
		.DataRate =			DR_AUTO,
		.Power =			PWR_MAX,
		.MAXTries = 		100,
		.SubBand_1st =     	EU_SUB_BANDS_DEFAULT,
		.SubBand_2nd =     	EU_SUB_BANDS_DEFAULT
	},
	.TX =
	{
		.Confirmed = 		false,
		.DataRate = 		DR_ADR,
		.Power = 			PWR_ADR,
		.FPort = 			1
	},
	.RX =
	{
		.Boost = 			true
	},
	.System =
	{
		.Idle =
		{
			.Mode = 		M0_DeepSleep,
			.BleEcoON =		false,
			.DebugON =		true,
		}
	}
};

static void OTX18_EnableCapSense(void)
{
	/* initialize radio with parameters in coreConfig */
	LoRaWAN_Init(&coreConfigCapSenseTest);

	/* Ulock port 7 which is used for CapSense. */
	LoRaWAN_Unlock();

	/* You can use the following fuction to see if your DevKit supports CapSense. P10.2 and P7.7 are shorted (IO_3). Older modules do not support CapSense */
	bool error = false;
	Cy_GPIO_Write(LED_B_PORT, LED_B_NUM, 1);
	Cy_GPIO_Pin_FastInit(P7_7_PORT, P7_7_NUM, CY_GPIO_DM_PULLUP, 1UL, HSIOM_SEL_GPIO);
	Cy_GPIO_Pin_FastInit(P10_2_PORT, P10_2_NUM, CY_GPIO_DM_STRONG, 0UL, HSIOM_SEL_GPIO);
	if (Cy_GPIO_Read(P7_7_PORT, P7_7_NUM) != 0) 
		error = true;
	Cy_GPIO_Pin_FastInit(P7_7_PORT, P7_7_NUM, CY_GPIO_DM_PULLDOWN, 0UL, HSIOM_SEL_GPIO);
	Cy_GPIO_Write(P10_2_PORT, P10_2_NUM, 1);
	if (Cy_GPIO_Read(P7_7_PORT, P7_7_NUM) == 0) 
		error = true;
	Cy_GPIO_Write(LED_B_PORT, LED_B_NUM, 0);
	if (error) while (1);
	Cy_GPIO_Pin_FastInit(P10_2_PORT, P10_2_NUM, CY_GPIO_DM_HIGHZ, 0, CY_GPIO_DM_ANALOG);
}